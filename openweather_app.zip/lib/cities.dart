class Cities {
  String location;
  String flag;
  String cityCode;

  Cities({this.location, this.flag, this.cityCode});
}
